#This is local processing file to convert Poland data to format usable for sensitivity analysis in ASF simulation model

#Input file is from Kim, Poland ASF surveillance data used for Frontiers paper
#Data is unaggregated, with ASF pos/neg PCR surveillance data from wild boar (hunted, roadkill, and passive carcass surveillance)

#Output files have surveillance data stripped of x/y geographic coordinates (scaled to zero at centroid), with PCR surveillance data aggregated to weeks
#Output files will be included in sensitivity analysis pipeline (pushed to main git repo on github)

#Input: wild_unagg.csv
#Output: 

#set directories
#where to access input files
dir<-"/Users/kayleigh.chalkowski/Library/CloudStorage/OneDrive-USDA/Projects/ASF_optimal_radius/Sensitivity_Analysis/Input/Processing_Data"
#where to write output files
outdir<-"/Users/kayleigh.chalkowski/Library/CloudStorage/OneDrive-USDA/Projects/ASF_optimal_radius/Sensitivity_Analysis/Input/"

##########################
###### Script Setup ###### 
##########################

{
  
#load libraries
library(sf)
library(spatialEco)
library(terra)
library(ggplot2)
library(stars)
library(mapview)
library(dplyr)
library(raster)

#read data
dat<-read.csv(paste0(dir,"/wild_unagg.csv"))

#remove points with missing lat/long
dat<-dat[!is.na(dat$x84),]

#set date class
dat$DATE<-as.Date(dat$DATE)

#convert to sf
dat<-st_as_sf(dat,coords=c("x84","y84"),crs=st_crs(4326))

#put x84/y84 coords back
dat$x84<-st_coordinates(dat)[,1]
dat$y84<-st_coordinates(dat)[,2]

#convert to lae format
dat<-st_transform(dat,crs=st_crs(3035))
}

#################################
###### Find outbreak sites ###### 
#################################
#isolate high kernel density spots of positive cases in western and eastern outbreaks
#western outbreak doesn't have many points (~5 weeks of surveillance with positives)
#eastern outbreak has more points, but less certainty around any hotspots being 'new introductions'
#worst case, can look at western side to get sense of slope increase at beginning, eastern to get established nums infected

{
#isolate western outbreak
datW=dat[dat$x84<18,]

#get azimuthal coordinates in data
datW$x.laea<-st_coordinates(datW)[,1]
datW$y.laea<-st_coordinates(datW)[,2]

#get subset of positives in western outbreak
datWpos<-datW[datW$PCR_Result==1,]

#identify centroid of western outbreak with kernel density
Wpos_kde=sf.kde(datWpos)

#visualize
#mapview(Wpos_kde)+mapview(datWpos)

#get centerpoint, max of kernel
W_intro.ctr_cell=which(values(Wpos_kde)==max(values(Wpos_kde)))
W_intro.ctr_xy=terra::xyFromCell(Wpos_kde,W_intro.ctr_cell)
W_intro.ctr_xy_sf=st_as_sf(as.data.frame(W_intro.ctr_xy),coords=c("x","y"),crs=st_crs(3035))

#visualize
#mapview(Wpos_kde)+mapview(W_intro.ctr_xy_sf,col.regions="red")+
#  mapview(datWpos,alpha.regions=0.01)

#find earliest positive case nearest to centerpoint
datWpos=datWpos[order(datWpos$DATE),]
datWpos$dist_Wctr=st_distance(datWpos,W_intro.ctr_xy_sf)
datWpos$seq=1:nrow(datWpos)
Wintro=datWpos[,c("DATE","dist_Wctr","seq")]

#2nd positive in western outbreak is only ~2km from centerpoint
#looks like there are max of 7 weeks of data for this outbreak
#prefer to have at least 52
#still use this but also get Eastern outbreak hotspot
firstcase_W=Wintro[Wintro$seq==3,]

#try eastern outbreak(s)
datE=dat[dat$x84>18,]

datE$x.laea<-st_coordinates(datE)[,1]
datE$y.laea<-st_coordinates(datE)[,2]

#get subset of positives in western outbreak
datEpos<-datE[datE$PCR_Result==1,]

#identify centroid of western outbreak with kernel density
Epos_kde=sf.kde(datEpos)

#visualize
#mapview(Epos_kde)#+mapview(datEpos)

#get centerpoint, max of kernel
E_intro.ctr_cell=which(values(Epos_kde)==max(values(Epos_kde)))
E_intro.ctr_xy=terra::xyFromCell(Epos_kde,E_intro.ctr_cell)
E_intro.ctr_xy_sf=st_as_sf(as.data.frame(E_intro.ctr_xy),coords=c("x","y"),crs=st_crs(3035))

#visualize
#mapview(Wpos_kde)+mapview(E_intro.ctr_xy_sf,col.regions="red")+
#  mapview(datWpos,alpha.regions=0.01)

datEpos=datEpos[order(datEpos$DATE),]
datEpos$dist_Ectr=st_distance(datEpos,E_intro.ctr_xy_sf)
datEpos$seq=1:nrow(datEpos)

#isolate cols for easy viz
Eintro=datEpos[,c("DATE","dist_Ectr","seq")]

#mapview(Epos_kde)+
#  mapview(Eintro[as.numeric(Eintro$dist_Ectr)<3100,],zcol="seq")

#identify first E case in most dense hotspot of positives
Eintro_hotspot=Eintro[as.numeric(Eintro$dist_Ectr)<3000,]
firstcase_E=Eintro_hotspot[Eintro_hotspot$seq==923,]

E.numday=difftime(Eintro[as.numeric(Eintro$dist_Ectr)<3100,][1,]$DATE,Eintro[as.numeric(Eintro$dist_Ectr)<3100,][nrow(Eintro[as.numeric(Eintro$dist_Ectr)<3100,]),]$DATE)
#69 weeks, better
}

###########################################################
###### De-identify location info, center around zero ###### 
###########################################################

{
#Western hotspot
W_intro.ctr_xy_sf_4326=st_transform(W_intro.ctr_xy_sf,crs=st_crs(4326))
#st_coordinates(W_intro.ctr_xy_sf_4326)[,1]
#st_coordinates(W_intro.ctr_xy_sf_4326)[,2]

#Western outbreak
projW <- paste0("+proj=laea +lat_0=",
                st_coordinates(W_intro.ctr_xy_sf_4326)[,2],
                " +lon_0=",
                st_coordinates(W_intro.ctr_xy_sf_4326)[,1],
                " +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs")

datW_projW=st_transform(datW,crs=st_crs(projW))

#getCoordinates
datW_projW$x_projW=st_coordinates(datW_projW)[,1]
datW_projW$y_projW=st_coordinates(datW_projW)[,2]


#ctrW_projW=st_transform(W_intro.ctr_xy_sf,crs=st_crs(projW))

#Eastern hotspot
E_intro.ctr_xy_sf_4326=st_transform(E_intro.ctr_xy_sf,crs=st_crs(4326))
#st_coordinates(W_intro.ctr_xy_sf_4326)[,1]
#st_coordinates(W_intro.ctr_xy_sf_4326)[,2]

#Western outbreak
projE <- paste0("+proj=laea +lat_0=",
                st_coordinates(E_intro.ctr_xy_sf_4326)[,2],
                " +lon_0=",
                st_coordinates(E_intro.ctr_xy_sf_4326)[,1],
                " +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs")

datE_projE=st_transform(datE,crs=st_crs(projE))

#getCoordinates
datE_projE$x_projE=st_coordinates(datE_projE)[,1]
datE_projE$y_projE=st_coordinates(datE_projE)[,2]

####################################
###### Subset to 80x80km grid ###### 
####################################

#West ctrpoint

#####Western subset
datW80<-datW_projW[abs(datW_projW$x_projW)<40000,]
datW80<-datW80[abs(datW80$y_projW)<40000,]

#####Eastern subset
datE80<-datE_projE[abs(datE_projE$x_projE)<40000,]
datE80<-datE80[abs(datE80$y_projE)<40000,]
}

#########################################
###### Tidy data to needed entries ######
#########################################

{
#number.of.animals column has some entries of '-'
#so don't know number sampled
#remove these entries
datE80=datE80[!is.na(datE80$number.of.animals),]
datE80=datE80[datE80$number.of.animals!="-",]

#keep only needed cols
#hunter harvest and boar density are rough estimates from national data, not needed
datW80s<-datW80[,c("ID",
                   "DATE",
                   "number.of.animals",
                   "sample_source",
                   "PCR_Result",
                   "geometry",
                   "x_projW",
                   "y_projW")]

datE80s<-datE80[,c("ID",
                   "DATE",
                   "number.of.animals",
                   "sample_source",
                   "PCR_Result",
                   "geometry",
                   "x_projE",
                   "y_projE")]

#make cols for E vs W to rbind
datW80s$region="West"
datE80s$region="East"

#Remove cases before 'first case' ID'd in first step
#firstcase_W
datW80s=datW80s[datW80s$DATE>=firstcase_W$DATE,]

#firstcase_E
datE80s=datE80s[datE80s$DATE>=firstcase_E$DATE,]

}

############################################
###### Aggregate data to weekly scale ######
############################################

{
  
#combine roadkill and hunted
#both indication of prevalence of live individuals
datW80s$sample_source[datW80s$sample_source=="hunted"]<-"live"
datW80s$sample_source[datW80s$sample_source=="roadkill"]<-"live"
datE80s$sample_source[datE80s$sample_source=="hunted"]<-"live"
datE80s$sample_source[datE80s$sample_source=="roadkill"]<-"live"

#Get jDate and formatting for aggregation
datW80s$jDate <- julian(datW80s$DATE, origin = min(datW80s$DATE))
datW80s$jDate=datW80s$jDate+1
datW80s=transform(datW80s, week = cut(jDate, c(0, seq(7, max(jDate) + 7, 7)), labels = FALSE))
datW80s$number.of.animals=as.numeric(datW80s$number.of.animals)

#aggregate sampling to weekly scale
datW80km_weekly=
  datW80s %>% 
  dplyr::group_by(sample_source,week) %>% 
  dplyr::summarise(startdt=min(DATE),
                   Nsampled=sum(number.of.animals),
                   Npos=sum(PCR_Result),
                   outbreak=first(region))

#Eastern set formatting for agg
datE80s$jDate <- julian(datE80s$DATE, origin = min(datE80s$DATE))
datE80s$jDate=datE80s$jDate+1
datE80s=transform(datE80s, week = cut(jDate, c(0, seq(7, max(jDate) + 7, 7)), labels = FALSE))
datE80s$number.of.animals=as.numeric(datE80s$number.of.animals)

#aggregate sampling to weekly scale
datE80km_weekly=
  datE80s %>% 
  dplyr::group_by(sample_source,week) %>% 
  dplyr::summarise(startdt=min(DATE),
                   Nsampled=sum(number.of.animals),
                   Npos=sum(PCR_Result),
                   outbreak=first(region))

datW80km_weekly$Nneg=datW80km_weekly$Nsampled-datW80km_weekly$Npos
datE80km_weekly$Nneg=datE80km_weekly$Nsampled-datE80km_weekly$Npos
}

###########################################################
###### Adjust vals for matching to simulation output ######
###########################################################

#Remove unneeded cols
datW80km_weekly=datW80km_weekly[,c(6,1:5,7)]
datE80km_weekly=datE80km_weekly[,c(6,1:5,7)]

#rename columns
colnames(datW80km_weekly)[c(2,5,6)]<-c("src","N","Npos")
colnames(datE80km_weekly)[c(2,5,6)]<-c("src","N","Npos")

#For datE, remove after week 52
datE80km_weekly=datE80km_weekly[datE80km_weekly$week<=52,]

#determine prevalences
datW80km_weekly$appar_prev=datW80km_weekly$Npos/datW80km_weekly$N
datE80km_weekly$appar_prev=datE80km_weekly$Npos/datE80km_weekly$N

#send out as dataframe
datW80km_weekly<-as.data.frame(datW80km_weekly)
datE80km_weekly<-as.data.frame(datE80km_weekly)

#remove geometry column
datE80km_weekly=datE80km_weekly[,-c(7)]
datW80km_weekly=datW80km_weekly[,-c(7)]

#separate carcass/live to do some clean pivoting to match sim output
Eout_live=datE80km_weekly[datE80km_weekly$src=="live",]
Eout_carcass=datE80km_weekly[datE80km_weekly$src=="carcass",]
Wout_live=datW80km_weekly[datW80km_weekly$src=="live",]
Wout_carcass=datW80km_weekly[datW80km_weekly$src=="carcass",]

#Need to pivot wider to match simulation output
Eout_live=
  as.data.frame(
    tidyr::pivot_wider(
      Eout_live,
      names_from=src,
      values_from=appar_prev))

Eout_carcass=
  as.data.frame(
    tidyr::pivot_wider(
      Eout_carcass,
      names_from=src,
      values_from=appar_prev))

Wout_live=
  as.data.frame(
    tidyr::pivot_wider(
      Wout_live,
      names_from=src,
      values_from=appar_prev))

Wout_carcass=
  as.data.frame(
    tidyr::pivot_wider(
      Wout_carcass,
      names_from=src,
      values_from=appar_prev))

#left join live to carcass for each outbreak
Eout=left_join(Eout_live,Eout_carcass[,c(2,6)],by="week")
Wout=left_join(Wout_live,Wout_carcass[,c(2,6)],by="week")

#change prev names to match sim output
colnames(Eout)[c(6,7)]=c("Ipa","Cpa")
colnames(Wout)[c(6,7)]=c("Ipa","Cpa")

#add type observed
Eout$type="observed_east"
Wout$type="observed_west"

#saveRDS(Eout,paste0(outdir,"datE80km_weekly.rds"))
#saveRDS(Wout,paste0(outdir,"datW80km_weekly.rds"))


##########################################
#Get alternative summaries of the data for sens. analysis
#1. Zone-only-- determine zone for each week (convex hull around infected individuals plus 400m buffer)
  #only include samples in zone
#2. Zone-only cells summary-- zone only, but summarized per cell instead of across whole grid

###################################
###### Get zone-only summary ######
###################################

#get 80x80km grid, 400m res, centeredaround first point
x <- raster(ncol=200, nrow=200, xmn=-40000, xmx=40000, ymn=-40000, ymx=40000)
crs(x)=projE
values(x)=1

#get cell numbers
y=extract(x,datE80s,cellnumbers=TRUE)
datE80s$grid_80km<-y[,1]

#get 80x80km grid, 400m res, centeredaround first point
xw <- raster(ncol=200, nrow=200, xmn=-40000, xmx=40000, ymn=-40000, ymx=40000)
crs(xw)=projW
values(xw)=1

#get cell numbers
yw=extract(xw,datW80s,cellnumbers=TRUE)
datW80s$grid_80km<-yw[,1]

#2-for each week, draw convex hull around any samples with positives
  #make polygons of chulls
  #overlay each week chull over 80km grid
  #get cell IDs that overlap with each chull, each week
  #for datE80, subset to cell IDs for each week
    #ask which cell IDs in week subset match the cell IDs in chull for that week
    #column named "inZone", for those that match, 1, no match=0

#gets zone around infected individuals by week
findZone<-function(data,x,src,firstcase_pt){
dat=data[data$sample_source==src,]
weeks=unique(dat$week)[order(unique(dat$week))]
dat$inZone=0
for(w in 1:length(weeks)){
  dat.w=dat[dat$week==weeks[w],]
  if(w==1){
  dat.w.pos=dat.w[dat.w$PCR_Result==1,]
  pts=c(st_geometry(dat.w.pos),st_geometry(firstcase_pt))
  } else{
    pts=c(pts,st_geometry(dat.w[dat.w$PCR_Result==1,]))
  }
  wkpos_chull=st_convex_hull(st_union(pts)) %>% st_sf %>% st_cast()
  wkpos_chull=st_buffer(wkpos_chull,400)
  cn_chull=terra::extract(x,wkpos_chull,cellnumbers=TRUE)
  cn_inzone=cn_chull[[1]][,1]
  if(any(((dat$grid_80km%in%cn_inzone)&(dat$week==weeks[w])))){
  dat[(dat$grid_80km%in%cn_inzone)&(dat$week==weeks[w]),]$inZone<-1
  }
  #also want area of the chull region, 'inzone'
  #track spatial spread
  area.vec.w=st_area(wkpos_chull)/1000000
  if(w==1){
    area.vec=area.vec.w
  } else{
    area.vec=c(area.vec,area.vec.w)
  }
  
}

area.vec.all=data.frame("week"=weeks,"area"=as.numeric(area.vec))

return(list("area"=area.vec.all,"dat"=dat))

}

#get live zone/cases for East
firstcase_Ep=st_transform(firstcase_E,crs=st_crs(projE))
zone.list_live=findZone(datE80s,x,"live",firstcase_Ep)
E.area.vec_live=zone.list_live$area
datE80c_live=zone.list_live$dat

#get carcass zone/cases for East
zone.list_carcass=findZone(datE80s,x,"carcass",firstcase_Ep)
E.area.vec_carcass=zone.list_carcass$area
datE80c_carcass=zone.list_carcass$dat
datE80c=rbind(datE80c_live,datE80c_carcass)

#get live zone/cases for West
firstcase_Wp=st_transform(firstcase_W,crs=st_crs(projW))
Wzone.list_live=findZone(datW80s,xw,"live",firstcase_Wp)
W.area.vec_live=Wzone.list_live$area
datW80c_live=Wzone.list_live$dat

#get carcass zone/cases for West
Wzone.list_carcass=findZone(datW80s,xw,"carcass",firstcase_Wp)
W.area.vec_carcass=Wzone.list_carcass$area
datW80c_carcass=Wzone.list_carcass$dat
datW80c=rbind(datW80c_live,datW80c_carcass)

#aggregate to weekly scale, only ones in zone
E_wk.zone.summary=
  datE80c[datE80c$inZone==1,] %>% 
  dplyr::group_by(sample_source,week) %>% 
  dplyr::summarise(startdt=min(DATE),
                   Nsampled=sum(number.of.animals),
                   Npos=sum(PCR_Result),
                   outbreak=first(region))

#aggregate to weekly scale, only ones in zone
W_wk.zone.summary=
  datW80c[datW80c$inZone==1,] %>% 
  dplyr::group_by(sample_source,week) %>% 
  dplyr::summarise(startdt=min(DATE),
                   Nsampled=sum(number.of.animals),
                   Npos=sum(PCR_Result),
                   outbreak=first(region))

colnames(datE80km_weekly)
colnames(E_wk.zone.summary)

#Adjust formatting to match simulation output
E_wk.zone.summary=E_wk.zone.summary[,c(6,1,2,3:5)]
W_wk.zone.summary=W_wk.zone.summary[,c(6,1,2,3:5)]

#adjust colnames to match sim output
colnames(E_wk.zone.summary)[c(2,5)]=c("src","N")
colnames(W_wk.zone.summary)[c(2,5)]=c("src","N")

#get prevalence
E_wk.zone.summary$appar_prev=E_wk.zone.summary$Npos/(E_wk.zone.summary$N+E_wk.zone.summary$Npos)
W_wk.zone.summary$appar_prev=W_wk.zone.summary$Npos/(W_wk.zone.summary$N+W_wk.zone.summary$Npos)

#drop geometry
E_wk.zone.summary=st_drop_geometry(E_wk.zone.summary)
W_wk.zone.summary=st_drop_geometry(W_wk.zone.summary)

#remove geometry column
E_wk.zone.summary=E_wk.zone.summary[,-c(7)]
W_wk.zone.summary=W_wk.zone.summary[,-c(7)]

#format as data frame
E_wk.zone.summary<-as.data.frame(E_wk.zone.summary)
W_wk.zone.summary<-as.data.frame(W_wk.zone.summary)

#separate carcass/live to do some clean pivoting to match sim output
E_wk.zone.summary_live=E_wk.zone.summary[E_wk.zone.summary$src=="live",]
E_wk.zone.summary_carcass=E_wk.zone.summary[E_wk.zone.summary$src=="carcass",]
W_wk.zone.summary_live=W_wk.zone.summary[W_wk.zone.summary$src=="live",]
W_wk.zone.summary_carcass=W_wk.zone.summary[W_wk.zone.summary$src=="carcass",]

#Need to pivot wider to match simulation output
Ezone_live=
  as.data.frame(
  tidyr::pivot_wider(
    E_wk.zone.summary_live,
    names_from=src,
    values_from=appar_prev))

Ezone_carcass=
  as.data.frame(
    tidyr::pivot_wider(
      E_wk.zone.summary_carcass,
      names_from=src,
      values_from=appar_prev))

Wzone_live=
  as.data.frame(
    tidyr::pivot_wider(
      W_wk.zone.summary_live,
      names_from=src,
      values_from=appar_prev))

Wzone_carcass=
  as.data.frame(
    tidyr::pivot_wider(
      W_wk.zone.summary_carcass,
      names_from=src,
      values_from=appar_prev))

#left join live to carcass for each outbreak
Ezone=left_join(Ezone_live,Ezone_carcass[,c(2,6)],by="week")
Wzone=left_join(Wzone_live,Wzone_carcass[,c(2,6)],by="week")

#change prev names to match sim output
colnames(Ezone)[c(6,7)]=c("Ipa","Cpa")
colnames(Wzone)[c(6,7)]=c("Ipa","Cpa")

Ezone$type="observed_east"
Wzone$type="observed_west"

#write out as RDS
saveRDS(Ezone,paste0(outdir,"E_wk.zone.summary.rds"))
saveRDS(Wzone,paste0(outdir,"W_wk.zone.summary.rds"))

#output spatial spread vector
saveRDS(E.area.vec_live[E.area.vec_live$week<=52,],paste0(outdir,"E_live_weekly_spread_area.rds"))
saveRDS(W.area.vec_live[W.area.vec_live$week<=52,],paste0(outdir,"W_live_weekly_spread_area.rds"))

saveRDS(E.area.vec_carcass[E.area.vec_carcass$week<=52,],paste0(outdir,"E_carcass_weekly_spread_area.rds"))
saveRDS(W.area.vec_carcass,paste0(outdir,"W_carcass_weekly_spread_area.rds"))

#################################################
###### Get zone-only summary at cell level ######
#################################################

#using only cells in zone, need to summarize at cell leve
#want median, q25, q75, summarized across cells, for each week

#pick up from datE80c/datW80c, last dataframe with unaggregated data, with zone designations
#get summary by week and cell
E_wk.cell.summary=
  datE80c[datE80c$inZone==1,] %>% 
  dplyr::group_by(sample_source,week,grid_80km) %>% 
  dplyr::summarise(startdt=min(DATE),
                   Nsampled=sum(number.of.animals),
                   Npos=sum(PCR_Result),
                   outbreak=first(region))

W_wk.cell.summary=
  datW80c[datW80c$inZone==1,] %>% 
  dplyr::group_by(sample_source,week,grid_80km) %>% 
  dplyr::summarise(startdt=min(DATE),
                   Nsampled=sum(number.of.animals),
                   Npos=sum(PCR_Result),
                   outbreak=first(region))

#Get prevalence
E_wk.cell.summary$prev=E_wk.cell.summary$Npos/(E_wk.cell.summary$Npos+E_wk.cell.summary$Nsampled)
W_wk.cell.summary$prev=W_wk.cell.summary$Npos/(W_wk.cell.summary$Npos+W_wk.cell.summary$Nsampled)

E_wk.cell.summary=st_drop_geometry(E_wk.cell.summary)
E_wk.cell.summary=as.data.frame(E_wk.cell.summary)

W_wk.cell.summary=st_drop_geometry(W_wk.cell.summary)
W_wk.cell.summary=as.data.frame(W_wk.cell.summary)


#Match summary colnames from SummarizeSounderlocs function
E_cellout=
  E_wk.cell.summary %>% 
  dplyr::group_by(sample_source,week) %>% 
  dplyr::summarise(ncells=n_distinct(grid_80km),
                   prev_med=median(prev),
                   prev_q25=quantile(prev,0.25),
                   prev_q75=quantile(prev,0.75),
                   outbreak=first(outbreak)) %>%
  as.data.frame()

W_cellout=
  W_wk.cell.summary %>% 
  dplyr::group_by(sample_source,week) %>% 
  dplyr::summarise(ncells=n_distinct(grid_80km),
                   prev_med=median(prev),
                   prev_q25=quantile(prev,0.25),
                   prev_q75=quantile(prev,0.75),
                   outbreak=first(outbreak)) %>%
  as.data.frame()


#rename cols
colnames(E_cellout)[1]="src"
colnames(W_cellout)[1]="src"

#separate to pivot wider and recombine

#separate carcass/live to do some clean pivoting to match sim output
E_cellout_live=E_cellout[E_cellout$src=="live",]
E_cellout_carcass=E_cellout[E_cellout$src=="carcass",]
W_cellout_live=W_cellout[W_cellout$src=="live",]
W_cellout_carcass=W_cellout[W_cellout$src=="carcass",]

#Need to pivot wider to match simulation output
E_cellout_live=
  as.data.frame(
    tidyr::pivot_wider(
      E_cellout_live,
      names_from=src,
      values_from=c(prev_med,prev_q25,prev_q75)))

E_cellout_carcass=
  as.data.frame(
    tidyr::pivot_wider(
      E_cellout_carcass,
      names_from=src,
      values_from=c(prev_med,prev_q25,prev_q75)))

W_cellout_live=
  as.data.frame(
    tidyr::pivot_wider(
      W_cellout_live,
      names_from=src,
      values_from=c(prev_med,prev_q25,prev_q75)))

W_cellout_carcass=
  as.data.frame(
    tidyr::pivot_wider(
      W_cellout_carcass,
      names_from=src,
      values_from=c(prev_med,prev_q25,prev_q75)))

colnames(E_cellout_live)[2]="ncells_live"
colnames(E_cellout_carcass)[2]="ncells_carcass"
colnames(W_cellout_live)[2]="ncells_live"
colnames(W_cellout_carcass)[2]="ncells_carcass"

#left join live to carcass for each outbreak
Ecells=left_join(E_cellout_live,E_cellout_carcass[,c(1,2,4:6)],by="week")
Wcells=left_join(W_cellout_live,W_cellout_carcass[,c(1,2,4:6)],by="week")

#rearrange column ordering
Ecells=Ecells[,c(1,3,2,4:6,7:10)]
Wcells=Wcells[,c(1,3,2,4:6,7:10)]

#change colnames to match sim output
colnames(Ecells)[3:10]=c("Ncells_Ipa",
                         "Ipa_med",
                         "Ipa_q25",
                         "Ipa_q75",
                         "Ncells_Cpa",
                         "Cpa_med",
                         "Cpa_q25",
                         "Cpa_q75")

colnames(Wcells)[3:10]=c("Ncells_Ipa",
                         "Ipa_med",
                         "Ipa_q25",
                         "Ipa_q75",
                         "Ncells_Cpa",
                         "Cpa_med",
                         "Cpa_q25",
                         "Cpa_q75")

Ecells$type="observed_east"
Wcells$type="observed_west"

#save output
#saveRDS(Ecells,paste0(outdir,"E_wk.cell.summary.rds"))
#saveRDS(Wcells,paste0(outdir,"W_wk.cell.summary.rds"))

